<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $raw_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $postalCode = $_POST['postalCode'];

    if ($raw_password === $confirm_password) {
        $password = password_hash($raw_password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, phone, address, city, state, postalCode, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)");
        $stmt->bind_param('ssssssss', $fullname, $email, $password, $phone, $address, $city, $state, $postalCode);

        if ($stmt->execute()) {
            header('Location: signin.php'); // Redirect new user to sign-in page after successful signup
            exit();
        } else {
            echo "Error: Could not create account.";
        }
    } else {
        echo "Passwords do not match.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <style>
        body {
            font-family: 'Lucida Bright', sans-serif;
            background-color: #ffebf0;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
           
        }

        .signup-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 350px;
            width: 100%;
			height: 80%;
            text-align: center;
            border: 2px solid #f4a1c1;
			 margin-top: 40px; 
            margin-bottom: 40px;
        }

        h2 {
            font-size: 24px;
			margin-top: 0px;
            margin-bottom: 20px;
            color: #f4a1c1;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #f4a1c1;
            border-radius: 5px;
        }

        .signup-button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .signup-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .message {
            margin-top: 15px;
            font-size: 14px;
        }

        .message a {
            color: #f4a1c1;
            text-decoration: none;
        }

        .message a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Create Your Account</h2>
        <form action="signup.php" method="post">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <input type="tel" name="phone" placeholder="Phone Number" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="city" placeholder="City" required>
            <input type="text" name="state" placeholder="State" required>
            <input type="text" name="postalCode" placeholder="Postal/ZIP Code" required>
            <button type="submit" class="signup-button">Sign Up</button>
        </form>
        <div class="message">
            <p>Already have an account? <a href="signin.php">Sign In Here</a></p>
        </div>
    </div>
</body>
</html>
