<?php
session_start();
require_once 'db_connection.php';
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle user management actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_user'])) {
        $user_id = $_POST['user_id'];
        $conn->query("DELETE FROM users WHERE user_id = $user_id");
    }
    if (isset($_POST['update_user'])) {
        $user_id = $_POST['user_id'];
        $new_email = $_POST['email'];
        $new_fullname = $_POST['fullname'];
        $conn->query("UPDATE users SET email='$new_email', fullname='$new_fullname' WHERE user_id = $user_id");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_announcement'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("INSERT INTO announcements (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();
}

// Order management actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_order'])) {
        $order_id = $_POST['order_id'];
        $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
    }

    if (isset($_POST['update_order_status'])) {
        $order_id = $_POST['order_id'];
        $status = $_POST['status'];
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $stmt->bind_param("si", $status, $order_id);
        $stmt->execute();
    }
}

// Fetch data for users, orders, and messages
$users = $conn->query("SELECT * FROM users");
// Modify the queries to separate standard and custom orders
$standard_orders = $conn->query("SELECT o.*, u.fullname, u.email 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.user_id 
    WHERE o.is_custom = 0
    ORDER BY o.order_id DESC");

$custom_orders = $conn->query("SELECT o.*, u.fullname, u.email 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.user_id 
    WHERE o.is_custom = 1
    ORDER BY o.order_id DESC");

$messages = $conn->query("SELECT * FROM messages");
$announcements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Panel - MyMai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: 'Lucida Bright', serif; background-color: #ffebf0; color: #333; margin: 0; padding: 0; }
        .header-bar {
            display: flex; justify-content: space-between; align-items: center; padding: 10px 20px; 
            background-color: #f4a1c1; color: white; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 { text-align: center; color: #f4a1c1; }
        .container { max-width: 900px; margin: 30px auto; padding: 20px; background-color: white; border: 2px solid #f4a1c1; border-radius: 8px; box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1); }
        .section { margin-top: 40px; }
        .table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .table th, .table td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        .table th { background-color: #f4a1c1; color: white; }
        .button {
            background-color: #f4a1c1; color: white; padding: 7px 12px; border: none; cursor: pointer;
            border-radius: 5px; margin-top: 5px; transition: background-color 0.3s;
        }
        .button:hover { background-color: #e9baf3; }
        .header-bar h2 { margin: 0; font-size: 1.2em; }
        .action-buttons { display: flex; justify-content: center; gap: 8px; }
        .logout-button { background-color: #e74c3c; color: white; }
        .logout-button:hover { background-color: #d73c2c; }
        .input-field { padding: 4px 8px; border: 1px solid #ddd; border-radius: 5px; }
        .admin-buttons { display: flex; gap: 10px; align-items: center; justify-content: flex-end; }
        .tab-buttons { display: flex; gap: 10px; margin-bottom: 15px; }
        .tab-button {
            background-color: #f8d7e3; color: #333; padding: 8px 15px; border: none;
            border-radius: 5px; cursor: pointer; transition: all 0.3s;
        }
        .tab-button.active {
            background-color: #f4a1c1; color: white;
        }
        .status-pending { background-color: #ffebcc; }
        .status-processing { background-color: #e6f7ff; }
        .status-shipped { background-color: #e6ffe6; }
        .status-completed { background-color: #d9f2d9; }
        .status-cancelled { background-color: #ffe6e6; }
    </style>
</head>
<body>

<div class="header-bar">
    <h2>Admin Panel - MyMai</h2>
    <div class="admin-buttons">
        <form action="logout.php" method="post" style="display:inline;">
            <button type="submit" class="button logout-button">Logout</button>
        </form>
    </div>
</div>

<div class="container">
    <!-- User Management Section -->
    <div class="section">
        <h2>Manage Users</h2>
        <table class="table">
            <tr>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
            <?php while ($user = $users->fetch_assoc()): ?>
                <tr>
                    <td><?= $user['user_id']; ?></td>
                    <td><?= htmlspecialchars($user['fullname']); ?></td>
                    <td><?= htmlspecialchars($user['email']); ?></td>
                    <td>
                        <div class="action-buttons">
                            <form action="admin.php" method="post" style="display:inline;">
                                <input type="hidden" name="user_id" value="<?= $user['user_id']; ?>">
                                <button type="submit" name="delete_user" class="button">Delete</button>
                            </form>
                            <form action="admin.php" method="post" style="display:inline;">
                                <input type="hidden" name="user_id" value="<?= $user['user_id']; ?>">
                                <input type="text" name="fullname" placeholder="New Full Name" class="input-field" required>
                                <input type="email" name="email" placeholder="New Email" class="input-field" required>
                                <button type="submit" name="update_user" class="button">Update</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

   <!-- Order Management Section -->
<div class="section">
    <h2>Manage Orders</h2>

    <div class="tab-buttons">
        <button class="tab-button active" onclick="showTab('standard-orders')">Standard Orders</button>
        <button class="tab-button" onclick="showTab('custom-orders')">Custom Bouquet Orders</button>
    </div>

    <!-- Standard Orders Tab -->
    <div id="standard-orders" class="tab-content">
        <table class="table">
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Flower Type</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($order = $standard_orders->fetch_assoc()): ?>
                <tr class="status-<?= strtolower(htmlspecialchars($order['status'] ?? 'pending')); ?>">
                    <td><?= $order['order_id']; ?></td>
                    <td><?= htmlspecialchars($order['fullname']); ?></td>
                    <td><?= htmlspecialchars($order['email']); ?></td>
                    <td><?= htmlspecialchars($order['flower_type']); ?></td>
                    <td><?= isset($order['order_date']) ? date('Y-m-d H:i', strtotime($order['order_date'])) : 'N/A'; ?></td>
                    <td>
                        <form action="admin.php" method="post">
                            <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                            <select name="status" class="input-field" onchange="this.form.submit()">
                                <option value="Pending" <?= (isset($order['status']) && $order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Processing" <?= (isset($order['status']) && $order['status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                                <option value="Shipped" <?= (isset($order['status']) && $order['status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="Delivered" <?= (isset($order['status']) && $order['status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                <option value="Cancelled" <?= (isset($order['status']) && $order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                            <input type="hidden" name="update_order_status">
                        </form>
                    </td>
                    <td>
                        <form action="admin.php" method="post" onsubmit="return confirm('Are you sure you want to delete this order?');">
                            <input type="hidden" name="order_id" value="<?= $order['order_id']; ?>">
                            <button type="submit" name="delete_order" class="button">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <!-- Custom Orders Tab -->
    <div id="custom-orders" class="tab-content" style="display: none;">
        <table class="table">
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Bouquet Details</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php while ($custom_order = $custom_orders->fetch_assoc()): ?>
                <tr class="status-<?= strtolower(htmlspecialchars($custom_order['status'] ?? 'pending')); ?>">
                    <td><?= $custom_order['order_id']; ?></td>
                    <td><?= htmlspecialchars($custom_order['fullname']); ?></td>
                    <td><?= htmlspecialchars($custom_order['email']); ?></td>
                    <td>
                        <?php 
                        $bouquet_details = $custom_order['bouquet_details'];
                        if (!empty($bouquet_details)) {
                            // If it's a JSON string, try to decode
                            $bouquet = json_decode($bouquet_details, true);
                            if (is_array($bouquet)) {
                                echo implode(', ', array_map('ucfirst', $bouquet));
                            } else {
                                // If not JSON, display as plain text
                                echo htmlspecialchars($bouquet_details);
                            }
                        } else {
                            echo 'No details available';
                        }
                        ?>
                    </td>
                    <td><?= isset($custom_order['order_date']) ? date('Y-m-d H:i', strtotime($custom_order['order_date'])) : 'N/A'; ?></td>
                    <td>
                        <form action="admin.php" method="post">
                            <input type="hidden" name="order_id" value="<?= $custom_order['order_id']; ?>">
                            <select name="status" class="input-field" onchange="this.form.submit()">
                                <option value="Pending" <?= (isset($custom_order['status']) && $custom_order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="Processing" <?= (isset($custom_order['status']) && $custom_order['status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                                <option value="Shipped" <?= (isset($custom_order['status']) && $custom_order['status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                                <option value="Delivered" <?= (isset($custom_order['status']) && $custom_order['status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                <option value="Cancelled" <?= (isset($custom_order['status']) && $custom_order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                            <input type="hidden" name="update_order_status">
                        </form>
                    </td>
                    <td>
                        <form action="admin.php" method="post" onsubmit="return confirm('Are you sure you want to delete this custom order?');">
                            <input type="hidden" name="order_id" value="<?= $custom_order['order_id']; ?>">
                            <button type="submit" name="delete_order" class="button">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>


   <!-- Messages Section -->
<div class="section">
    <h2>User Messages</h2>
    <table class="table">
        <tr>
            <th>Message ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
        </tr>
        <?php while ($message = $messages->fetch_assoc()): ?>
            <tr>
                <td><?= $message['message_id']; ?></td>
                <td><?= htmlspecialchars($message['name']); ?></td>
                <td><?= htmlspecialchars($message['email']); ?></td>
                <td><?= htmlspecialchars($message['message']); ?></td>
                <td><?= $message['timestamp']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="section">
    <h2>Manage Announcements</h2>
    <form action="admin.php" method="post">
        <label for="title">Announcement Title:</label>
        <input type="text" name="title" required><br><br>
        
        <label for="content">Content:</label>
        <textarea name="content" rows="4" required></textarea><br><br>
        
        <button type="submit" name="add_announcement" class="button">Add Announcement</button>
    </form>
    
    <h3>Existing Announcements</h3>
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Content</th>
            <th>Date</th>
        </tr>
        <?php while ($announcement = $announcements->fetch_assoc()): ?>
            <tr>
                <td><?= $announcement['announcement_id']; ?></td>
                <td><?= htmlspecialchars($announcement['title']); ?></td>
                <td><?= htmlspecialchars($announcement['content']); ?></td>
                <td><?= $announcement['created_at']; ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

<script>
    function showTab(tabId) {
        // Hide all tab contents
        const tabContents = document.querySelectorAll('.tab-content');
        tabContents.forEach(tab => {
            tab.style.display = 'none';
        });
        
        // Show the selected tab
        document.getElementById(tabId).style.display = 'block';
        
        // Update active button styling
        const tabButtons = document.querySelectorAll('.tab-button');
        tabButtons.forEach(button => {
            button.classList.remove('active');
        });
        
        // Add active class to clicked button
        event.currentTarget.classList.add('active');
    }
</script>

</body>
</html>