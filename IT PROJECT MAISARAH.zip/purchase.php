<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check for any error messages
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['error_message']); // Clear after displaying

// Get user info to pre-fill address
require_once 'db_connection.php';
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT fullname, address, city, state, postalCode FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Replace the existing purchases query with this:
$purchases_query = $conn->query("
    SELECT 
        order_id, 
        CASE 
            WHEN is_custom = 1 THEN 'Custom' 
            ELSE 'Regular' 
        END as order_type,
        CASE 
            WHEN is_custom = 1 THEN bouquet_details 
            ELSE flower_type 
        END as item_description, 
        order_date, 
        status, 
        payment_method,
        address_line1, 
        city, 
        state, 
        postal_code
    FROM orders
    WHERE user_id = $user_id
    ORDER BY order_date DESC
");

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Purchase - MyMai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Keep your existing styles here, plus add new styles for the address section -->
    <style>
        /* Style for header */
        .header {
            background-color: #ffebf0;
            background-size: cover;
            border: 2px solid #f4a1c1;
            padding: 20px;
            text-align: center;
            font-family: 'Vivaldi', cursive;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
        }

        .header .logo {
            height: 40px;
            width: auto;
        }

        h1 {
            font-size: 25px;
            margin: 0;
        }

        /* Floating flower animation */
        .floating-flower {
            position: fixed;
            bottom: 10px;
            right: 10px;
            width: 100px;
            height: auto;
            z-index: 1000;
        }

        .floating-flower img {
            width: 100%;
            height: auto;
        }

        @keyframes float {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
            100% {
                transform: translateY(0);
            }
        }

        .floating-flower {
            animation: float 4s ease-in-out infinite;
        }

        /* Navigation bar */
        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }

        .navbar a {
            border-radius: 20px;
            background-color: #f4a1c1;
            transition: background-color 0.3s;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
        }

        .navbar a:hover {
            background-color: #ffebf0;
            color: black;
        }

        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        .menu {
            display: flex;
        }

        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            }
        }

        /* Body and container styles */
        body {
            font-family: 'Lucida Bright', serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .purchase-container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border: 2px solid #f7c7d5;
            margin-bottom: 70px; /* Space for footer */
        }

        h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        .purchase-instructions, .checkout-section {
            margin-bottom: 20px;
        }

        ol {
            padding-left: 20px;
        }

        /* Form styles */
        label {
            font-size: 1em;
            color: #333;
        }

        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 15px;
        }

        button[type="submit"]:hover {
            background-color: #ffebf0;
            color: black;
        }

        /* Toggle buttons */
        .toggle-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
        }

        .toggle-buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #f4a1c1;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }

        .toggle-buttons button.active {
            background-color: #ffebf0;
            color: black;
        }

        /* Cat helper section */
        #cat-helper {
            text-align: center;
            margin: 20px;
        }

        #cat-animation {
            width: 100px;
            height: auto;
        }

        #cat-message {
            font-size: 18px;
            color: #333;
            margin-top: 10px;
            min-height: 50px; /* Prevent layout shift when message changes */
        }

        /* Flower selection */
        #flower-selection {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            padding: 10px;
        }

        #flower-selection button {
            border: none;
            background: none;
            cursor: pointer;
            padding: 5px;
        }

        #flower-selection img {
            width: 80px;
            height: auto;
            border-radius: 8px;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        #flower-selection img:hover {
            transform: scale(1.1);
        }

        /* Bouquet preview */
        #bouquet-preview {
            margin-top: 20px;
            text-align: center;
            padding: 15px;
            border: 1px dashed #f4a1c1;
            border-radius: 8px;
            background-color: #fff5f8;
        }

        #bouquet-preview h3 {
            margin-top: 0;
            color: #333;
        }

        #selected-flowers {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin-top: 10px;
            min-height: 60px; /* Minimum height to prevent layout shifting */
        }

        #selected-flowers img {
            width: 50px;
            height: auto;
            border-radius: 8px;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .flower-container {
            position: relative;
            display: inline-block;
        }

        .remove-flower {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #f4a1c1;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: none;
        }

        /* Clear bouquet button */
        #clear-bouquet {
            background-color: #f8d7e3;
            color: #333;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            margin-top: 10px;
            cursor: pointer;
            font-size: 14px;
        }

        #clear-bouquet:hover {
            background-color: #f4a1c1;
            color: white;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .purchase-container {
                width: 95%;
                margin: 20px auto 70px;
            }
            
            .toggle-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .toggle-buttons button {
                width: 100%;
                max-width: 300px;
            }
        }

        @media (max-width: 480px) {
            .purchase-container {
                width: 100%;
                padding: 10px;
                border-radius: 0;
            }
            
            #flower-selection img {
                width: 60px;
            }
        }
        
        /* New styles for address section */
        .address-section {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #f4a1c1;
            border-radius: 8px;
            background-color: #fff;
        }
        
        .address-section h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 1px solid #ffebf0;
            padding-bottom: 10px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            flex: 1 1 300px;
        }
        
        .error-message {
            background-color: #ffdddd;
            color: #f44336;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .payment-options {
            margin: 20px 0;
        }
        
        .payment-methods {
            display: flex;
            gap: 20px;
            margin-top: 10px;
        }
        
        .payment-method {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Footer styles */
        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="..\PHP\flowerpicture\flower.png" alt="Logo" class="logo">
        <h1>MyMai</h1>
    </div>

    <div class="floating-flower">
        <img src="..\PHP\flowerpicture\flowerfloat.png" alt="Flower Icon">
    </div>

    <div class="navbar">
        <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="menu">
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="showcase.php">Showcase & Collection</a>
            <a href="purchase.php">Purchase</a>
            <a href="contact.php">Contact Us Here</a>
        </div>
    </div>

    <div class="purchase-container">
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        
        <div class="purchase-instructions">
            <h2>Purchase Crochet Flowers</h2>
            <ol>
                <li>Choose ready-made flowers or customize your bouquet</li>
                <li>Fill in your shipping details</li>
                <li>Select your payment method</li>
                <li>Place your order and enjoy your handmade crochet flowers!</li>
            </ol>
        </div>

        <!-- Toggle Buttons for Ready-Made vs Custom Bouquet -->
        <div class="toggle-buttons">
            <button id="readyMadeBtn" class="active" onclick="showSection('ready-made')">Ready-Made Flowers</button>
            <button id="customBouquetBtn" onclick="showSection('custom-bouquet')">Customize Your Bouquet</button>
        </div>

        <!-- Ready-Made Flower Section -->
        <section id="ready-made" class="checkout-section">
            <h2>Ready-Made Flowers</h2>
            <form id="readyMadeForm" method="POST" action="process_order.php">
                <label for="flower_type">Select Flower Type:</label><br>
                <div class="flower-options">
                    <label><input type="radio" name="flower_type" value="Rose" required> Rose</label><br>
                    <label><input type="radio" name="flower_type" value="Tulip"> Tulip</label><br>
                    <label><input type="radio" name="flower_type" value="Lavender"> Lavender</label><br>
                    <label><input type="radio" name="flower_type" value="Sunflower"> Sunflower</label><br>
                    <label><input type="radio" name="flower_type" value="Daisy"> Daisy</label><br>
                    <label><input type="radio" name="flower_type" value="Dandelion"> Dandelion</label><br><br>
                </div>
                
                <!-- Address Section -->
                <div class="address-section">
                    <h3>Shipping Information</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="address_line1">Address Line 1:</label>
                            <input type="text" name="address_line1" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="address_line2">Address Line 2 (Optional):</label>
                            <input type="text" name="address_line2">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City:</label>
                            <input type="text" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="state">State:</label>
                            <input type="text" name="state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="postal_code">Postal Code:</label>
                            <input type="text" name="postal_code" value="<?php echo htmlspecialchars($user['postalCode'] ?? ''); ?>" required>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Methods -->
                <div class="payment-options">
                    <h3>Payment Method</h3>
                    <div class="payment-methods">
                        <div class="payment-method">
                            <input type="radio" id="online_payment" name="payment_method" value="Online Payment" checked>
                            <label for="online_payment">Online Payment</label>
                        </div>
                        <div class="payment-method">
                            <input type="radio" id="cod" name="payment_method" value="COD">
                            <label for="cod">Cash on Delivery</label>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn">Place Order</button>
            </form>
        </section>

        <!-- Custom Bouquet Section -->
        <section id="custom-bouquet" class="checkout-section" style="display: none;">
            <h2>Customize Your Bouquet</h2>
            <form id="customBouquetForm" method="POST" action="process_order.php">
                <div id="cat-helper">
                    <img id="cat-animation" src="..\\PHP\\images\\cat1.gif" alt="Cat Helper">
                    <p id="cat-message">Choose flowers to create your custom bouquet!</p>
                </div>
                
                <div id="flower-selection">
                    <button type="button" data-flower="rose"><img src="..\PHP\flowerpicture\rose.jpg" alt="Rose"></button>
                    <button type="button" data-flower="sunflower"><img src="..\PHP\flowerpicture\sunflower.jpg" alt="Sunflower"></button>
                    <button type="button" data-flower="tulip"><img src="..\PHP\flowerpicture\tulip.jpg" alt="Tulip"></button>
                    <button type="button" data-flower="lavender"><img src="..\PHP\flowerpicture\lavender.jpg" alt="Lavender"></button>
                    <button type="button" data-flower="daisy"><img src="..\PHP\flowerpicture\daisy.jpg" alt="Daisy"></button>
                    <button type="button" data-flower="dandelion"><img src="..\PHP\flowerpicture\dandelion.jpg" alt="Dandelion"></button>
                </div>
                
                <div id="bouquet-preview">
                    <h3>Your Bouquet</h3>
                    <div id="selected-flowers"></div>
                    <button type="button" id="clear-bouquet">Clear Bouquet</button>
                    <!-- Hidden inputs to store selected flowers -->
                    <div id="selected-flowers-inputs"></div>
                </div>
                
                <!-- Address Section (same as ready-made) -->
                <div class="address-section">
                    <h3>Shipping Information</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="address_line1">Address Line 1:</label>
                            <input type="text" name="address_line1" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="address_line2">Address Line 2 (Optional):</label>
                            <input type="text" name="address_line2">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">City:</label>
                            <input type="text" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="state">State:</label>
                            <input type="text" name="state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="postal_code">Postal Code:</label>
                            <input type="text" name="postal_code" value="<?php echo htmlspecialchars($user['postalCode'] ?? ''); ?>" required>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Methods -->
                <div class="payment-options">
                    <h3>Payment Method</h3>
                    <div class="payment-methods">
                        <div class="payment-method">
                            <input type="radio" id="online_payment_custom" name="payment_method" value="Online Payment" checked>
                            <label for="online_payment_custom">Online Payment</label>
                        </div>
                        <div class="payment-method">
                            <input type="radio" id="cod_custom" name="payment_method" value="COD">
                            <label for="cod_custom">Cash on Delivery</label>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn">Place Custom Order</button>
            </form>
        </section>
    </div>

    <div class="footer">
        <p>&copy; 2025 MyMai - Crochet Flowers. All rights reserved.</p>
    </div>

    <script>
        // Toggle between Ready-Made and Custom Bouquet sections
        function showSection(sectionId) {
            document.getElementById('ready-made').style.display = sectionId === 'ready-made' ? 'block' : 'none';
            document.getElementById('custom-bouquet').style.display = sectionId === 'custom-bouquet' ? 'block' : 'none';
            document.getElementById('readyMadeBtn').classList.toggle('active', sectionId === 'ready-made');
            document.getElementById('customBouquetBtn').classList.toggle('active', sectionId === 'custom-bouquet');
        }

        // Toggle mobile menu
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }

        // Ensure form validation for ready-made flower selection
        document.getElementById('readyMadeForm').addEventListener('submit', function(event) {
            const selectedFlower = document.querySelector('input[name="flower_type"]:checked');
            if (!selectedFlower) {
                event.preventDefault();
                alert('Please select a flower type!');
            }
        });

        // Cat Helper Functionality
        const catAnimation = document.getElementById('cat-animation');
        const catMessage = document.getElementById('cat-message');
        const flowerSelection = document.getElementById('flower-selection');
        const selectedFlowers = document.getElementById('selected-flowers');
        const selectedFlowersInputs = document.getElementById('selected-flowers-inputs');
        const clearBouquetBtn = document.getElementById('clear-bouquet');
        const customBouquetForm = document.getElementById('customBouquetForm');

        // Track selected flowers
        let selectedFlowersList = [];

        const flowerData = {
            rose: { reaction: '..\\PHP\\images\\cat5.gif', fact: 'Roses symbolize love and passion.' },
            sunflower: { reaction: '..\\PHP\\images\\cat2.gif', fact: 'Sunflowers follow the sun!' },
            tulip: { reaction: '..\\PHP\\images\\cat3.gif', fact: 'Tulips are a symbol of perfect love.' },
            lavender: { reaction: '..\\PHP\\images\\cat4.gif', fact: 'Lavender represents calmness and serenity.' },
            daisy: { reaction: '..\\PHP\\images\\cat1.gif', fact: 'Daisies symbolize innocence and purity.' },
            dandelion: { reaction: '..\\PHP\\images\\cat6.gif', fact: 'Dandelions are a symbol of hope and wishes.' },
        };

        // Add flower to bouquet when clicked
        flowerSelection.addEventListener('click', (event) => {
            const flowerButton = event.target.closest('button');
            if (!flowerButton) return; // Ensure a button was clicked

            const flower = flowerButton.dataset.flower;
            const { reaction, fact } = flowerData[flower];

            // Update cat animation and message
            catAnimation.src = reaction;
            catMessage.textContent = fact;
            
            // Create container for flower and remove button
            const flowerContainer = document.createElement('div');
            flowerContainer.className = 'flower-container';
            flowerContainer.dataset.flower = flower;
            
            // Create flower image
            const flowerImage = document.createElement('img');
            flowerImage.src = flowerButton.querySelector('img').src;
            flowerImage.alt = flower;
            flowerContainer.appendChild(flowerImage);
            
            // Create remove button
            const removeBtn = document.createElement('button');
            removeBtn.className = 'remove-flower';
            removeBtn.innerHTML = '×';
            removeBtn.addEventListener('click', () => removeFlower(flowerContainer, flower));
            flowerContainer.appendChild(removeBtn);
            
            // Add to display
            selectedFlowers.appendChild(flowerContainer);
            
            // Add flower to selection list
            selectedFlowersList.push(flower);
            
            // Update hidden inputs for form submission
            updateSelectedFlowersInputs();
        });

        // Remove flower from bouquet
        function removeFlower(container, flower) {
            container.remove();
            
            // Remove from array
            const index = selectedFlowersList.indexOf(flower);
            if (index > -1) {
                selectedFlowersList.splice(index, 1);
            }
            
            // Update hidden inputs
            updateSelectedFlowersInputs();
        }

        // Clear entire bouquet
        clearBouquetBtn.addEventListener('click', () => {
            selectedFlowers.innerHTML = '';
            selectedFlowersList = [];
            updateSelectedFlowersInputs();
            catAnimation.src = '..\\PHP\\images\\cat1.gif';
            catMessage.textContent = 'Choose flowers to create your custom bouquet!';
        });

        // Update hidden inputs for form submission
        function updateSelectedFlowersInputs() {
            // Clear existing inputs
            selectedFlowersInputs.innerHTML = '';
            
            // Create hidden inputs for each selected flower
            selectedFlowersList.forEach((flower, index) => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = `bouquet[${index}]`;
                input.value = flower;
                selectedFlowersInputs.appendChild(input);
            });
        }

        // Form submission validation
        customBouquetForm.addEventListener('submit', function(event) {
            if (selectedFlowersList.length === 0) {
                event.preventDefault();
                alert('Please select at least one flower for your bouquet!');
            }
        });
    </script>
</body>
</html>