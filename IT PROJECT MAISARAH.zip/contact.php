<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Us</title>
   <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

/* Style for header */
.header {
  background-color: #ffebf0;
  background-size: cover;
  border: 2px solid #f4a1c1;
  padding: 20px;
  text-align: center;
  font-family: 'Vivaldi';
  display: flex; 
  align-items: center; 
  justify-content: center; 
  gap: 20px;
}

.header .logo {
  height: 40px; 
  width: auto; 
}

.floating-flower {
  position: fixed; 
  bottom: 10px; 
  right: 10px; 
  width: 100px; /* Size of the flower icon */
  height: auto; /* Maintain aspect ratio */
  z-index: 1000; /* Ensure it's on top of other elements */
}

.floating-flower img {
  width: 100%;
  height: auto;
}

/* Floating animation */
@keyframes float {
  0% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px); 
  }
  100% {
    transform: translateY(0);
  }
}

.floating-flower {
  animation: float 4s ease-in-out infinite;
}

 .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
 }

h1 {
 font-size: 25px;
 margin: 0;
 }

 
 /* Style the top navigation bar */
.navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }
        .navbar a {
            border-radius: 20px;
			background-color: #f4a1c1;
			transition: background-color 0.3s;
			color: white;
            padding: 10px 20px;
            text-decoration: none;
			text-transform: uppercase;
            text-align: center;
        }
        .navbar a:hover {
            background-color: #ffebf0;;
            color: black;
        }
        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }
        .menu {
            display: flex;
        }
        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            } }
			
label {
            display: block;
            margin-bottom: 10px;
            font-size: 18px;
            color: #555;
        }
        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        textarea {
            resize: vertical;
            height: 150px;
        }
        button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
        }
        button:hover {
            background-color: #ffebf0;
            color: black;
        }
        .contact-info {
            margin-top: 20px;
        }
        .contact-info h2 {
            font-size: 22px;
        }
        .contact-info p {
            margin: 5px 0;
}
	
.footer {
  background-color: #f4a1c1;
  color: white;
  text-align: center;
  padding: 10px;
  position: fixed; 
  bottom: 0;
  width: 100%;
  font-family: 'Lucida Bright';
}

.footer p {
  margin: 0;
  font-size: 14px;
}

</style>
</head>
<body>

<div class="header">
    <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
    <h1>MyMai</h1>
</div>

<div class="navbar">
    <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
    <div class="menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="showcase.php">Showcase & Collection</a>
        <a href="purchase.php">Purchase</a>
        <a href="contact.php">Contact Us Here</a>
    </div>
</div>

<div class="container">
    <h1>Get in Touch</h1>
    <form id="contactForm" action="process_contact.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea>

        <button type="submit">Send Message</button>
    </form>
</div>

<footer class="footer">
    <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
</footer>

<script>
    function toggleMenu() {
        var menu = document.querySelector('.menu');
        menu.classList.toggle('active');
    }
</script>

</body>
</html>
