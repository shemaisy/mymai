<?php
// Function to generate bcrypt hash from plain text password
function generateBcryptHash($password) {
    // Generate a bcrypt hash with default cost (10)
    $hash = password_hash($password, PASSWORD_BCRYPT);
    
    // Print the generated hash
    echo "Generated Hash: " . $hash;
    
    // Optional: Verify the hash works
    echo "\n\nVerification Test: " . 
         (password_verify($password, $hash) ? "Success" : "Failed");
}

// Example usage
generateBcryptHash('MaiSarah12');

//In SQL 
//INSERT INTO users 
//(fullname, email, password, phone, address, city, state, postalCode, is_admin) 
//VALUES 
//('Admin Name', 'admin@example.com', '$2y$10$abcdefghijklmnopqrstuvwxyzABCDEFG', 'phone', 'address', 'city', 'state', 'postal_code', 1);
?>