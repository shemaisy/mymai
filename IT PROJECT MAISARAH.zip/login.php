<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login - MyMai</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { margin: 0; font-family: 'Lucida Bright', sans-serif; background-color: #ffebf0; }
        .header { background-color: #ffebf0; padding: 20px; text-align: center; font-family: 'Vivaldi'; }
        .button-container { display: flex; justify-content: center; margin-top: 40px; }
        .button { background-color: #f4a1c1; padding: 15px 30px; margin: 0 10px; color: white; font-size: 18px; border: none; cursor: pointer; }
        .button:hover { background-color: #e9baf3; color: #333; }
        .back-button { background-color: #a1c1f4; padding: 10px 20px; margin-top: 20px; color: white; font-size: 16px; border: none; cursor: pointer; display: block; margin-left: auto; margin-right: auto; }
        .back-button:hover { background-color: #bae9f3; color: #333; }
    </style>
</head>
<body>

<div class="header">
    <img src="..\PHP\flowerpicture\flower.png" alt="Logo" style="height:40px;">
    <h1>MyMai</h1>
</div>

<section id="welcome">
    <div style="text-align: center; padding: 20px;">
        <h1>Welcome to MyMai Crochet Wonderland!</h1>
        <p>Looking for Something Special for Someone Special?</p>
    </div>
</section>

<section class="button-container">
    <button class="button" onclick="window.location.href='signin.php'">Sign In as User</button>
    <button class="button" onclick="window.location.href='admin_login.php'">Sign In as Admin</button>
</section>

<section style="text-align: center;">
    <button class="back-button" onclick="window.location.href='index.php'">Back to Home</button>
</section>

</body>
</html>