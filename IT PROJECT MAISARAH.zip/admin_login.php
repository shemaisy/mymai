<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        $stmt = $conn->prepare('SELECT user_id, password FROM users WHERE email = ? AND is_admin = 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result->fetch_assoc();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['user_id'];
            header('Location: admin.php');
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login - MyMai</title>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: 'Lucida Bright', serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            text-align: center;
            border: 2px solid #f4a1c1;
        }

        .login-container h2 {
            color: #f4a1c1;
            font-size: 24px;
            margin-bottom: 20px;
        }

        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #f4a1c1;
            border-radius: 5px;
            box-sizing: border-box;
        }

         .login-button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .login-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .message {
            margin-top: 15px;
            font-size: 14px;
        }

        .message a {
            color: #f4a1c1;
            text-decoration: none;
        }

        .message a:hover {
            text-decoration: underline;
        }

        .back-button {
            display: inline-block;
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 15px;
            transition: background-color 0.3s;
            text-align: center;
            max-width: 400px;
            width: 100%;
            box-sizing: border-box;
        }

        .back-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        /* Error message styling */
        .error {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>
    <form method="post" action="admin_login.php">
        <label for="email">Admin Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Log In as Admin</button>
    </form>
    <?php if (isset($error)): ?>
        <p style="color: red;"> <?= $error ?> </p>
    <?php endif; ?>
</div>

 <a href="index.php" class="back-button">Back to Home</a>

</body>
</html>
