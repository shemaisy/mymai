<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'mymai_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 0;
        }

        /* Style for header */
        .header {
            background-color: #ffebf0;
            background-size: cover;
            border: 2px solid #f4a1c1;
            padding: 20px;
            text-align: center;
            font-family: 'Vivaldi';
            display: flex; 
            align-items: center; 
            justify-content: center; 
            gap: 20px;
        }

        .header .logo {
            height: 40px; 
            width: auto; 
        }

        h1 {
            font-size: 25px;
            margin: 0;
        }

        .floating-flower {
            position: fixed; 
            bottom: 10px; 
            right: 10px; 
            width: 100px; 
            height: auto; 
            z-index: 1000; 
        }

        .floating-flower img {
            width: 100%;
            height: auto;
        }

        /* Floating animation */
        @keyframes float {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px); 
            }
            100% {
                transform: translateY(0);
            }
        }

        .floating-flower {
            animation: float 4s ease-in-out infinite;
        }
        
        /* Style the top navigation bar */
        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }

        .navbar a {
            border-radius: 20px;
            background-color: #f4a1c1;
            transition: background-color 0.3s;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
        }

        .navbar a:hover {
            background-color: #ffebf0;
            color: black;
        }

        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        .menu {
            display: flex;
        }

        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }

            .menu-icon {
                display: block;
            }

            .menu.active {
                display: flex;
            } 
        }
        
        /* Style body of the page */
        .welcome {
            background-color: #ffebf0;
            background-size: cover;
            height: 800px; 
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .welcome-message {
            color: black;
            background: #ffebf0;
            padding: 30px;
            border: 2px solid #f4a1c1;
            border-radius: 0px;
            text-align: center;
            font-family: 'Lucida Bright';
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .welcome-message h1 {
            font-size: 40px;
        }

        .welcome-message p {
            font-size: 24px;
            font-style: italic;
        }

        h2 {
            text-align: center;  /* Centers the text */
            font-family: 'Lucida Bright'; 
            font-size: 22px;
            margin-top: 20px; 
            color: #333; 
        }

        /* Style for announcement section */
        .container {
            background-color: #ffebf0; /* Soft pink background */
            padding: 20px;
            margin: 20px auto;
            border-radius: 10px;
            max-width: 800px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            font-family: 'Lucida Bright';
            font-size: 24px;
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .container ul {
            list-style-type: none;
            padding: 0;
        }

        .container li {
            background-color: #fff; /* White background for each announcement */
            padding: 15px;
            margin-bottom: 15px;
            border: 1px solid #f4a1c1;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container li h3 {
            font-family: 'Lucida Bright';
            font-size: 20px;
            color: #f4a1c1; /* Soft pink for title */
            margin: 0 0 10px;
        }

        .container li p {
            font-family: 'Lucida Bright';
            font-size: 16px;
            color: #333;
            margin: 0 0 10px;
        }

        .container li small {
            font-family: 'Lucida Bright';
            font-size: 14px;
            color: #777; /* Lighter grey for date */
        }
  
        .gallery {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            overflow: hidden;
            position: relative;
            margin-bottom: 80px; 
        }

        .gallery img {
            width: 150px;  
            height: 150px; 
            border-radius: 10px;
            transition: transform 0.3s, filter 0.3s;
        }

        .gallery img:hover {
            transform: scale(1.1); /* Slight zoom effect on hover */
            filter: brightness(0.9);
        }

        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed; 
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
        
        /* User Profile Dropdown Styles */
        .profile-dropdown {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 100;
        }

        .profile-dropdown .dropdown-button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .profile-dropdown .dropdown-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .profile-dropdown .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .profile-dropdown .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
            text-transform: none;
        }

        .profile-dropdown .dropdown-content a:hover {
            background-color: #f4a1c1;
            color: white;
        }

        .profile-dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>

<div class="header">
    <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
    <h1>MyMai</h1>
    
    <!-- User Profile Dropdown - Only shown if user is logged in -->
    <?php if (isset($_SESSION['user_id'])): ?>
    <div class="profile-dropdown">
        <button class="dropdown-button">My Profile</button>
        <div class="dropdown-content">
            <a href="wishlist.php">Wishlist</a>
            <a href="edit_address.php">Edit Address</a>
            <a href="purchase_history.php">Purchase History</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <?php else: ?>
    <div class="profile-dropdown">
        <a href="login.php" style="text-decoration: none;">
            <button class="dropdown-button">Sign In</button>
        </a>
    </div>
    <?php endif; ?>
</div>

<div class="navbar">
    <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
    <div class="menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="showcase.php">Showcase & Collection</a>
        <a href="purchase.php">Purchase</a>
        <a href="contact.php">Contact Us Here</a>
    </div>
</div>

<!-- Welcome section -->
<section id="welcome">
    <div class="welcome-message">
        <h1>Welcome to MyMai Crochet Wonderland!</h1>
        <p>Looking for Something Special for Someone Special?</p>
    </div>
</section>

<?php
// Fetch announcements for display
$announcements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 3");
?>
<div class="container">
    <h2>Latest Announcements</h2>
    <ul>
        <?php while ($announcement = $announcements->fetch_assoc()): ?>
            <li>
                <h3><?= htmlspecialchars($announcement['title']); ?></h3>
                <p><?= htmlspecialchars($announcement['content']); ?></p>
                <small><?= $announcement['created_at']; ?></small>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<h2>A Glimpse of Our Collection</h2>
<div class="gallery">
    <img src="..\PHP\flowerpicture\tangle.jpg" alt="Tangle" class="hover-effect active">
    <img src="..\PHP\flowerpicture\sunflower.jpg" alt="Sunflower" class="hover-effect">
    <img src="..\PHP\flowerpicture\tulip.jpg" alt="Tulip" class="hover-effect">
    <img src="..\PHP\flowerpicture\daisies.jpg" alt="Daisy" class="hover-effect">
    <img src="..\PHP\flowerpicture\rose.jpg" alt="Rose" class="hover-effect">
    <img src="..\PHP\flowerpicture\dandelion.jpg" alt="Dandelion" class="hover-effect">    
</div>

<footer class="footer">
    <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
</footer>

<script>
    function toggleMenu() {
        var menu = document.querySelector('.menu');
        menu.classList.toggle('active');
    }
    
    // Profile dropdown toggle functionality
    document.addEventListener("DOMContentLoaded", function() {
        // Close the dropdown if the user clicks outside of it
        document.addEventListener("click", function(event) {
            const dropdown = document.querySelector(".profile-dropdown");
            if (dropdown && !dropdown.contains(event.target)) {
                const dropdownContent = dropdown.querySelector(".dropdown-content");
                if (dropdownContent) {
                    dropdownContent.style.display = "none";
                }
            }
        });

        // Toggle dropdown visibility
        const dropdownButton = document.querySelector(".dropdown-button");
        if (dropdownButton) {
            dropdownButton.addEventListener("click", function(event) {
                event.stopPropagation();
                const dropdownContent = this.nextElementSibling;
                if (dropdownContent) {
                    dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
                }
            });
        }
    });
</script>

</body>
</html>