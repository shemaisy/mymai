<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $response = ['success' => false, 'message' => ''];

    // Get address information
    $address_line1 = $_POST['address_line1'] ?? '';
    $address_line2 = $_POST['address_line2'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $postal_code = $_POST['postal_code'] ?? '';
    $payment_method = $_POST['payment_method'] ?? 'Online Payment';
    
    // Validate required fields
    if (empty($address_line1) || empty($city) || empty($state) || empty($postal_code)) {
        $response['message'] = 'Please fill in all required address fields.';
        echo json_encode($response);
        exit;
    }

    // Start a transaction to ensure data integrity
    $conn->begin_transaction();

    try {
        // Check if the order is for a ready-made flower or custom bouquet
        if (isset($_POST['flower_type']) && !empty($_POST['flower_type'])) {
            // Ready-Made Flower Order
            $flower = $_POST['flower_type'];
            $status = 'Pending'; // Default status

            // Insert order details into the orders table
            $stmt = $conn->prepare("INSERT INTO orders (user_id, flower_type, address_line1, address_line2, city, state, postal_code, payment_method, status, is_custom) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
            $stmt->bind_param("issssssss", $user_id, $flower, $address_line1, $address_line2, $city, $state, $postal_code, $payment_method, $status);
            $stmt->execute();
            $order_id = $conn->insert_id;
            $stmt->close();

        } elseif (isset($_POST['bouquet']) && !empty($_POST['bouquet'])) {
            // Custom Bouquet Order
            $bouquet = json_encode($_POST['bouquet']);
            $status = 'Pending'; // Default status

            // Insert into orders table with custom bouquet details
            $stmt = $conn->prepare("INSERT INTO orders (user_id, flower_type, bouquet_details, address_line1, address_line2, city, state, postal_code, payment_method, status, is_custom) 
                                    VALUES (?, 'Custom Bouquet', ?, ?, ?, ?, ?, ?, ?, ?, 1)");
            $stmt->bind_param("issssssss", $user_id, $bouquet, $address_line1, $address_line2, $city, $state, $postal_code, $payment_method, $status);
            $stmt->execute();
            $order_id = $conn->insert_id;
            $stmt->close();
        } else {
            throw new Exception('Please select a flower type or create a custom bouquet.');
        }

        // Commit the transaction
        $conn->commit();

        $response['success'] = true;
        $response['message'] = 'Order completed! Details will be sent to your email.';
        $response['order_id'] = $order_id;

    } catch (Exception $e) {
        // Rollback the transaction on error
        $conn->rollback();
        $response['message'] = 'Order failed. Please try again later. Error: ' . $e->getMessage();
    }

    // If this is an AJAX request
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode($response);
    } else {
        // If it's a regular form submission
        if ($response['success']) {
            $_SESSION['order_message'] = $response['message'];
            header('Location: order_confirmation.php?order_id=' . $response['order_id']);
        } else {
            $_SESSION['error_message'] = $response['message'];
            header('Location: purchase.php');
        }
    }
    exit;
}

$conn->close();
?>