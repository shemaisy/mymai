<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch current user data
$user_query = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user = $user_query->get_result()->fetch_assoc();
$user_query->close();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = $conn->real_escape_string($_POST['address']);
    $city = $conn->real_escape_string($_POST['city']);
    $state = $conn->real_escape_string($_POST['state']);
    $postal_code = $conn->real_escape_string($_POST['postalCode']);
    $phone = $conn->real_escape_string($_POST['phone']);
    
    //update user address information
    $update_query = $conn->prepare("UPDATE users SET address = ?, city = ?, state = ?, postalCode = ?, phone = ? WHERE user_id = ?");
    $update_query->bind_param("sssssi", $address, $city, $state, $postal_code, $phone, $user_id);
    
   if ($update_query->execute()) {
    $message = "Address updated successfully!";
    
    //this code to re-fetch the updated user data
    $user_query = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $user_query->bind_param("i", $user_id);
    $user_query->execute();
    $user = $user_query->get_result()->fetch_assoc();
    $user_query->close();
    
} else {
    $error = "Error updating address: " . $conn->error;
}

    $update_query->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Address - MyMai</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
       body {
            font-family: 'Lucida Bright', sans-serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #ffebf0;
            border: 2px solid #f4a1c1;
            padding: 10px;
            text-align: center;
            font-family: 'Vivaldi';
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            position: relative;
        }

        .header .logo {
            height: 40px;
            width: auto;
        }

        .header h1 {
            font-size: 24px; 
            margin: 0; 
        }

        .address-container {
            max-width: 600px;
            margin: 20px auto 80px;
            padding: 20px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .address-container h2 {
            font-size: 28px;
            color: #f4a1c1;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        .submit-button {
            background-color: #f4a1c1;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .submit-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .back-button-container {
            text-align: center; 
            margin-top: 20px; 
        }

        .back-button {
            display: inline-block;
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #ffebf0;
            color: black;
        }
        
         /* Profile Dropdown Styles */
        .profile-dropdown {
            position: absolute;
            top: 10px;
            right: 20px;
            z-index: 100;
        }

        .profile-dropdown .dropdown-button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .profile-dropdown .dropdown-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .profile-dropdown .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .profile-dropdown .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .profile-dropdown .dropdown-content a:hover {
            background-color: #f4a1c1;
            color: white;
        }

        .success-message {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .error-message {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
        <h1>MyMai</h1>
        
        <!-- User Profile Dropdown -->
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="profile-dropdown">
            <button class="dropdown-button">My Profile</button>
            <div class="dropdown-content">
                <a href="wishlist.php">Wishlist</a>
                <a href="edit_address.php">Edit Address</a>
                <a href="purchase_history.php">Purchase History</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="address-container">
        <h2>Edit Your Address</h2>
        
        <!-- Display success or error messages -->
        <?php if ($message): ?>
            <div class="success-message"><?= $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error-message"><?= $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" value="<?= htmlspecialchars($user['address'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" value="<?= htmlspecialchars($user['city'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="state">State/Province:</label>
                <input type="text" id="state" name="state" value="<?= htmlspecialchars($user['state'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="postalCode">Postal Code:</label>
                <input type="text" id="postalCode" name="postalCode" value="<?= htmlspecialchars($user['postalCode'] ?? ''); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? ''); ?>" required>
            </div>
            
            <button type="submit" class="submit-button">Update Address</button>
        </form>
        
        <div class="back-button-container">
            <a href="index.php" class="back-button">Back to Home</a>
        </div>
    </div>
    
    <footer class="footer">
        <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
    </footer>
    
    <script>
    // Close the dropdown if the user clicks outside of it
    document.addEventListener("click", function(event) {
        const dropdown = document.querySelector(".profile-dropdown");
        if (!dropdown.contains(event.target)) {
            dropdown.querySelector(".dropdown-content").style.display = "none";
        }
    });

    // Toggle dropdown visibility
    document.querySelector(".dropdown-button").addEventListener("click", function() {
        const dropdownContent = document.querySelector(".dropdown-content");
        dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
    });
    </script>
</body>
</html>