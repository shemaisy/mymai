<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$wishlist = $conn->query("SELECT * FROM wishlist WHERE user_id = $user_id");

// Check for success or error messages
$message = isset($_GET['message']) ? $_GET['message'] : null;
$error = isset($_GET['error']) ? $_GET['error'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Wishlist - MyMai</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Lucida Bright', sans-serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #ffebf0;
            border: 2px solid #f4a1c1;
            padding: 10px;
            text-align: center;
            font-family: 'Vivaldi';
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            position: relative;
        }

        .header .logo {
            height: 40px;
            width: auto;
        }

        .header h1 {
            font-size: 24px; 
            margin: 0; 
        }

        .wishlist-container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .wishlist-container h2 {
            font-size: 28px;
            color: #f4a1c1;
            margin-bottom: 20px;
        }

        .wishlist-items {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 20px;
            padding: 10px;
        }

        .wishlist-item {
            text-align: center;
            background-color: #fff;
            border: 1px solid #f4a1c1;
            border-radius: 10px;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .wishlist-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .wishlist-item img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s, filter 0.3s;
        }

        .wishlist-item img:hover {
            transform: scale(1.05);
            filter: brightness(0.9);
        }

        .wishlist-item p {
            margin: 10px 0 0;
            font-size: 16px;
            color: #333;
        }

        .remove-button {
            background-color: #e74c3c;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        .remove-button:hover {
            background-color: #c0392b;
        }

        .empty-wishlist {
            text-align: center;
            font-size: 18px;
            color: #777;
            margin-top: 20px;
        }
		
		.back-button-container {
            text-align: center; 
            margin-top: 20px; 
        }

		.back-button {
			display: inline-block;
			background-color: #f4a1c1;
			color: white;
			padding: 10px 20px;
			border-radius: 5px;
			text-decoration: none;
			margin-top: 20px;
			transition: background-color 0.3s;
		}

		.back-button:hover {
			background-color: #ffebf0;
			color: black;
		}
		
        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

		.success-message {
			background-color: #4CAF50;
			color: white;
			padding: 10px;
			border-radius: 5px;
			margin-bottom: 20px;
			text-align: center;
		}

		.error-message {
			background-color: #e74c3c;
			color: white;
			padding: 10px;
			border-radius: 5px;
			margin-bottom: 20px;
			text-align: center;
		}

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
        <h1>MyMai</h1>
    </div>
	
	<div class="wishlist-container">
		<h2>My Wishlist</h2>
	
	<!-- Display success or error messages -->
	 <?php if ($message): ?>
            <div class="success-message"><?= $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error-message"><?= $error; ?></div>
        <?php endif; ?>
	
    <div class="wishlist-items">
        <?php if ($wishlist->num_rows > 0): ?>
            <?php while ($item = $wishlist->fetch_assoc()): ?>
          	
				
				<div class="wishlist-item">
                      <img src="../PHP/flowerpicture/<?= htmlspecialchars($item['flower_image']); ?>" alt="<?= htmlspecialchars($item['flower_image']); ?>">
                    <form action="remove_from_wishlist.php" method="POST">
                        <input type="hidden" name="wishlist_id" value="<?= $item['wishlist_id']; ?>">
                        <button type="submit" class="remove-button">Remove</button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="empty-wishlist">Your wishlist is empty. Start adding flowers!</p>
        <?php endif; ?>
    </div>
</div>

<!-- Back button -->
	<div class="back-button-container">
    <a href="showcase.php" class="back-button">Back to Showcase</a> 
	  </div>
    </div>
	
    <footer class="footer">
        <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
    </footer>
	
</body>
</html>