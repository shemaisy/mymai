<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
 {
  margin: 0;
}

/* Style for header */
.header {
  background-color: #ffebf0;
  background-size: cover;
  border: 2px solid #f4a1c1;
  padding: 20px;
  text-align: center;
  font-family: 'Vivaldi';
  display: flex; 
  align-items: center; 
  justify-content: center; 
  gap: 20px;
}

.header .logo {
  height: 40px; 
  width: auto; 
}

h1 {
 font-size: 25px;
 margin: 0;
 }

 
 /* Style the top navigation bar */
.navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;;
            padding: 15px 8px;
        }
        .navbar a {
            border-radius: 20px;
			background-color: #f4a1c1;
			transition: background-color 0.3s;
			color: white;
            padding: 10px 20px;
            text-decoration: none;
			text-transform: uppercase;
            text-align: center;
        }
        .navbar a:hover {
            background-color: #ffebf0;;
            color: black;
        }
        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }
        .menu {
            display: flex;
        }
        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            } }
			
/* About Section Styles */
.about {
  background-color: #ffebf0; 
  padding: 60px;
  text-align: center;
}

.about-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 30px;
  background-color: white; 
  border: 2px solid #f4a1c1; 
  border-radius: 5px; 
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
}

.about h2 {
  font-family: 'Lucida Bright';
  font-size: 36px;
  color: #333; 
  margin-bottom: 20px;
}

.about p {
  font-family: 'Lucida Bright';
  font-size: 18px;
  color: #333;
  line-height: 1.6;
}

.footer {
  background-color: #f4a1c1;
  color: white;
  text-align: center;
  padding: 10px;
  position: fixed; 
  bottom: 0;
  width: 100%;
  font-family: 'Lucida Bright';
}

.footer p {
  margin: 0;
  font-size: 14px;
}

</style>
</head>
<body>

<div class="header">
    <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
    <h1>MyMai</h1>
</div>

<div class="navbar">
    <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
    <div class="menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="showcase.php">Showcase & Collection</a>
        <a href="purchase.php">Purchase</a>
        <a href="contact.php">Contact Us Here</a>
    </div>
</div>

<section id="about">
    <div class="about-container">
        <h2>About Us</h2>
        <p>Welcome to MyMai Crochet Wonderland, where every stitch tells a story and every flower blooms with love. We are passionate creators dedicated to bringing you the finest handcrafted crochet flowers, each designed with care and crafted with skill.</p>
      <p>Our journey began with a simple love for crochet and a desire to share the beauty and warmth of handmade creations. What started as a personal hobby quickly blossomed into a small business with a big heart. Our mission is to offer you unique, high-quality crochet flowers that add a touch of charm and elegance to any occasion.</p>
	  <p>At MyMai Crochet Wonderland, we pride ourselves on our attention to detail and commitment to quality. Each flower is meticulously handcrafted, ensuring that every piece is as beautiful as it is durable. Whether you’re looking for a special gift, a decorative touch for your home, or a personal treat, our collection has something for everyone.</p>
	  <p>We believe in the beauty of handmade artistry and the joy of giving something truly special. We are constantly inspired by nature’s beauty and the joy of creating, and we hope that our flowers bring as much happiness to you as they do to us.</p>
	  <p>Thank you for visiting MyMai Crochet Wonderland. We’re thrilled to share our passion with you and look forward to being a part of your life’s beautiful moments.</p>
	  <p>Warmly,<br>Mai<br>Founder MyMai Crochet Wonderland</p>
    </div>
</section>

<footer class="footer">
    <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
</footer>

<script>
    function toggleMenu() {
        var menu = document.querySelector('.menu');
        menu.classList.toggle('active');
    }
</script>

</body>
</html>
