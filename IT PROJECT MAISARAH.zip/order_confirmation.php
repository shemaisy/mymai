<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check if we have order details
if (!isset($_GET['order_id'])) {
    header('Location: purchase.php');
    exit();
}

$order_id = isset($_SESSION['custom_order_id']) ? $_SESSION['custom_order_id'] : $_GET['order_id'];
$order_message = $_SESSION['order_message'] ?? "Thank you for your order!";
unset($_SESSION['order_message']); // Clear the message after displaying
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order Confirmation - MyMai</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        /* Style for header */
        .header {
            background-color: #ffebf0;
            background-size: cover;
            border: 2px solid #f4a1c1;
            padding: 20px;
            text-align: center;
            font-family: 'Vivaldi', cursive;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
        }

        .header .logo {
            height: 40px;
            width: auto;
        }

        h1 {
            font-size: 25px;
            margin: 0;
        }
		
		 /* Navigation bar */
        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }

        .navbar a {
            border-radius: 20px;
            background-color: #f4a1c1;
            transition: background-color 0.3s;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
        }

        .navbar a:hover {
            background-color: #ffebf0;
            color: black;
        }

        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        .menu {
            display: flex;
        }

        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            }
        }

        /* Floating flower animation */
        .floating-flower {
            position: fixed;
            bottom: 10px;
            right: 10px;
            width: 100px;
            height: auto;
            z-index: 1000;
        }

        .floating-flower img {
            width: 100%;
            height: auto;
        }

        @keyframes float {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
            100% {
                transform: translateY(0);
            }
        }

        .floating-flower {
            animation: float 4s ease-in-out infinite;
        }

        /* Navigation bar */
        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }
		
        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        .menu {
            display: flex;
        }

        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            }
        }

        /* Body and container styles */
        body {
            font-family: 'Lucida Bright', serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
		
		 h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }
		
        ol {
            padding-left: 20px;
        }
		
        #cat-animation {
            width: 80px;
            height: auto;
        }

        /* Additional styles for confirmation page */
        .confirmation-container {
            text-align: center;
            padding: 40px 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border: 2px solid #f7c7d5;
            margin: 40px auto;
            max-width: 600px;
        }
        
        .order-success {
            color: #4CAF50;
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        .order-number {
            font-size: 18px;
            margin-bottom: 15px;
            background-color: #ffebf0;
            padding: 10px;
            border-radius: 5px;
            display: inline-block;
        }
        
        .next-steps {
            margin-top: 30px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            text-align: left;
        }
        
        .action-buttons {
            margin-top: 40px;
        }
        
        .action-buttons a {
            display: inline-block;
            margin: 0 10px;
            padding: 12px 24px;
            background-color: #f4a1c1;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        
        .action-buttons a:hover {
            background-color: #ffebf0;
            color: black;
        }
        
        .celebration-image {
            width: 150px;
            margin: 20px auto;
        }

        /* Footer styles */
        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Include your header, floating flower, and navbar here -->
    <div class="header">
        <img src="..\PHP\flowerpicture\flower.png" alt="Logo" class="logo">
        <h1>MyMai</h1>
    </div>

    <div class="floating-flower">
        <img src="..\PHP\flowerpicture\flowerfloat.png" alt="Flower Icon">
    </div>

    <div class="navbar">
        <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
        <div class="menu">
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="showcase.php">Showcase & Collection</a>
            <a href="purchase.php">Purchase</a>
            <a href="contact.php">Contact Us Here</a>
        </div>
    </div>

    <div class="confirmation-container">
        <img src="..\PHP\images\cat5.gif" alt="Celebration" class="celebration-image">
        
        <h2 class="order-success">Order Successfully Placed!</h2>
        <p class="order-number">Order #<?php echo htmlspecialchars($order_id); ?></p>
        
        <p><?php echo htmlspecialchars($order_message); ?></p>
        
        <div class="next-steps">
            <h3>What happens next?</h3>
            <ol>
                <li>Your order has been received and is being processed.</li>
                <li>We'll send you an email confirmation with order details.</li>
                <li>You'll receive updates as your crochet flowers are crafted.</li>
                <li>Once shipped, you'll get a notification with tracking information.</li>
            </ol>
        </div>
        
        <div class="action-buttons">
            <a href="purchase.php">Order More</a>
            <a href="index.php">Return Home</a>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 MyMai - Crochet Flowers. All rights reserved.</p>
    </div>

    <script>
        // Toggle mobile menu
        function toggleMenu() {
            const menu = document.querySelector('.menu');
            menu.classList.toggle('active');
        }
    </script>
</body>
</html>