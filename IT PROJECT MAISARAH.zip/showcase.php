<?php 
session_start(); 
require_once 'db_connection.php';

// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$user_id = $logged_in ? $_SESSION['user_id'] : null;

// Get wishlist items if user is logged in
$wishlist_items = [];
if ($logged_in) {
    $stmt = $conn->prepare("SELECT flower_image FROM wishlist WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $wishlist_items[] = $row['flower_image'];
    }
}

// Count wishlist items
$wishlist_count = count($wishlist_items);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Showcase & Selection</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
        }

        /* Style for header */
        .header {
            background-color: #ffebf0;
            background-size: cover;
            border: 2px solid #f4a1c1;
            padding: 20px;
            text-align: center;
            font-family: 'Vivaldi';
            display: flex; 
            align-items: center; 
            justify-content: center; 
            gap: 20px;
        }

        .header .logo {
            height: 40px; 
            width: auto; 
        }

        h1 {
            font-size: 25px;
            margin: 0;
        }

        .floating-flower {
            position: fixed; 
            bottom: 10px; 
            right: 10px; 
            width: 100px; 
            height: auto; 
            z-index: 1000; 
        }

        .floating-flower img {
            width: 100%;
            height: auto;
        }

        /* Floating animation */
        @keyframes float {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px); 
            }
            100% {
                transform: translateY(0);
            }
        }

        .floating-flower {
            animation: float 4s ease-in-out infinite;
        }
        
        /* Style the top navigation bar */
        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #f4a1c1;
            padding: 15px 8px;
        }
        .navbar a {
            border-radius: 20px;
            background-color: #f4a1c1;
            transition: background-color 0.3s;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            text-transform: uppercase;
            text-align: center;
        }
        .navbar a:hover {
            background-color: #ffebf0;
            color: black;
        }
        .menu-icon {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }
        .menu {
            display: flex;
        }
        @media (max-width: 768px) {
            .menu {
                display: none;
                flex-direction: column;
                width: 100%;
            }
            .menu-icon {
                display: block;
            }
            .menu.active {
                display: flex;
            }
        }
            
        /* Showcase Section Styles */
        .showcase {
            background-color: #ffebf0;
            padding: 60px;
            text-align: center;
        }

        .showcase-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .showcase h2 {
            font-family: 'Lucida Bright';
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
        }

        .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .gallery-item {
            position: relative;
            width: 200px;
            height: 200px;
        }

        .gallery-item img {
            width: 200px; 
            height: 200px; 
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s, filter 0.3s;
        }

        .gallery-item img:hover {
            transform: scale(1.1);
            filter: brightness(0.9);
        }

        .heart-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: rgba(255, 255, 255, 0.7);
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 10;
        }

        .heart-btn:hover {
            background-color: rgba(255, 235, 240, 0.9);
        }

        .heart-btn i {
            color: #f4a1c1;
            font-size: 18px;
            transition: all 0.3s;
        }

        .heart-btn.active i, .heart-btn:hover i {
            color: #e83e8c;
            transform: scale(1.2);
        }
        
        /* Banner Section Styles */
        .banner {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 40px 20px;
        }

        .banner h2 {
            font-family: 'Lucida Bright';
            font-size: 30px;
            margin: 0;
        }
        
        /* Flower Types Section Styles */
        .flower-types {
            background-color: #ffebf0;
            padding: 60px;
            text-align: center;
        }
        
        .flower-type-item {
            text-align: center;
            position: relative;
        }

        .flower-type-item ul {
            list-style: none;
            padding: 0;
            margin: 10px 0 0 0;
        }

        .flower-type-item li {
            font-family: 'Lucida Bright';
            font-size: 18px;
            color: #333;
        }

        .flower-types-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .flower-types h2 {
            font-family: 'Lucida Bright';
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
        }

        .flower-types-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .flower-types-grid .flower-type-item {
            position: relative;
        }

        .flower-types-grid img {
            width: 150px; 
            height: 150px; 
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s, filter 0.3s;
        }

        .flower-types-grid img:hover {
            transform: scale(1.1);
            filter: brightness(0.9);
        }

        .custom-item {
            position: relative;
            width: 150px;
            height: 150px;
        }
        
        .custom-item img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s, filter 0.3s;
        }
        
        .custom-item img:hover {
            transform: scale(1.1);
            filter: brightness(0.9);
        }

        /* Wishlist count badge */
        .wishlist-badge {
            position: fixed;
            top: 10px;
            right: 20px;
            background-color: #f4a1c1;
            color: white;
            border-radius: 50%;
            width: 25px;
            height: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            z-index: 100;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        /* Wishlist icon */
        .wishlist-icon {
            position: fixed;
            top: 15px;
            right: 50px;
            color: #e83e8c;
            font-size: 24px;
            cursor: pointer;
            z-index: 100;
        }

        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed; 
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }

        /* Login prompt */
        .login-prompt {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin: 10px auto;
            max-width: 600px;
            text-align: center;
        }

        .login-prompt a {
            color: #721c24;
            font-weight: bold;
            text-decoration: underline;
        }

        /* Space to prevent content from being hidden by footer */
        .footer-spacer {
            height: 60px;
        }

        @media (max-width: 768px) {
            .showcase, .flower-types {
                padding: 40px 15px;
            }
            
            .gallery {
                gap: 15px;
            }
            
            .gallery-item, .gallery-item img {
                width: 150px;
                height: 150px;
            }
            
            .heart-btn {
                width: 30px;
                height: 30px;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
    <h1>MyMai</h1>
</div>

<div class="wishlist-icon" onclick="goToWishlist()">
    <i class="fas fa-heart"></i>
</div>
<div class="wishlist-badge"><?php echo $wishlist_count; ?></div>

<div class="floating-flower">
    <img src="../PHP/showcase/flowersearch.png" alt="Search Icon">
</div>

<div class="navbar">
    <div class="menu-icon" onclick="toggleMenu()">&#9776;</div>
    <div class="menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="showcase.php">Showcase & Collection</a>
        <a href="purchase.php">Purchase</a>
        <a href="contact.php">Contact Us Here</a>
        <?php if (!$logged_in): ?>
            <a href="signin.php">Sign In</a>
        <?php else: ?>
            <a href="logout.php">Sign Out</a>
        <?php endif; ?>
    </div>
</div>

<?php if (!$logged_in): ?>
<div class="login-prompt">
    Please <a href="signin.php">sign in</a> to add flowers to your wishlist!
</div>
<?php endif; ?>

<section id="showcase" class="showcase">
    <div class="showcase-container">
        <h2>Showcase of Our Crochet Flowers</h2>
        <div class="gallery">
            <?php 
            $gallery_items = [
                ["sc.jpg", "Flower 1"],
                ["sc2.jpg", "Flower 2"],
                ["sc3.jpg", "Flower 3"],
                ["sc4.jpg", "Flower 4"],
                ["sc5.jpg", "Flower 5"],
                ["sc6.jpg", "Flower 6"],
                ["sc7.jpg", "Flower 7"],
                ["sc8.jpg", "Flower 8"],
                ["sc9.jpg", "Flower 9"],
                ["sc10.jpg", "Flower 10"],
                ["sc11.jpg", "Flower 11"],
                ["sc12.jpg", "Flower 12"]
            ];
            
            foreach ($gallery_items as $item): 
                $image = $item[0];
                $name = $item[1];
                $in_wishlist = in_array($image, $wishlist_items);
            ?>
            <div class="gallery-item">
                <img src="../PHP/flowerpicture/<?php echo $image; ?>" alt="<?php echo $name; ?>">
                <?php if ($logged_in): ?>
                    <?php if ($in_wishlist): ?>
                        <form action="remove_from_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <input type="hidden" name="remove" value="1">
                            <button type="submit" class="heart-btn active">
                                <i class="fas fa-heart"></i>
                            </button>
                        </form>
                    <?php else: ?>
                        <form action="add_to_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <button type="submit" class="heart-btn">
                                <i class="far fa-heart"></i>
                            </button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="heart-btn" onclick="loginPrompt()">
                        <i class="far fa-heart"></i>
                    </button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="banner">
    <h2>Have you found your perfect match yet?</h2>
</section>

<section class="flower-types">
    <div class="flower-types-container">
        <h2>Types of Flowers You Can Order</h2>
        <div class="flower-types-grid">
            <?php
            $flower_types = [
                ["tulip.jpg", "Tulip"],
                ["rose.jpg", "Rose"],
                ["lavender.jpg", "Lavender"],
                ["daisies.jpg", "Daisy"],
                ["sunflower.jpg", "Sunflower"],
                ["dandelion.jpg", "Dandelion"]
            ];
            
            foreach ($flower_types as $type):
                $image = $type[0];
                $name = $type[1];
                $in_wishlist = in_array($image, $wishlist_items);
            ?>
            <div class="flower-type-item">
                <img src="../PHP/flowerpicture/<?php echo $image; ?>" alt="<?php echo $name; ?>">
                <?php if ($logged_in): ?>
                    <?php if ($in_wishlist): ?>
                        <form action="remove_from_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <input type="hidden" name="remove" value="1">
                            <button type="submit" class="heart-btn active">
                                <i class="fas fa-heart"></i>
                            </button>
                        </form>
                    <?php else: ?>
                        <form action="add_to_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <button type="submit" class="heart-btn">
                                <i class="far fa-heart"></i>
                            </button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="heart-btn" onclick="loginPrompt()">
                        <i class="far fa-heart"></i>
                    </button>
                <?php endif; ?>
                <ul>
                    <li><?php echo $name; ?></li>
                </ul>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="banner">
    <h2>Still can't choose? Custom your flower with us now!</h2>
</section>

<section class="flower-types">
    <div class="flower-types-container">
        <h2>Types of Flowers You Can Custom and Many More!</h2>
        <div class="flower-types-grid">
            <?php
            $custom_items = [
                ["tangle.jpg", "Custom 1"],
                ["custom.jpg", "Custom 2"],
                ["custom2.jpg", "Custom 3"],
                ["custom3.jpg", "Custom 4"],
                ["custom4.jpg", "Custom 5"],
                ["custom5.jpg", "Custom 6"]
            ];
            
            foreach ($custom_items as $item):
                $image = $item[0];
                $name = $item[1];
                $in_wishlist = in_array($image, $wishlist_items);
            ?>
            <div class="custom-item">
                <img src="../PHP/flowerpicture/<?php echo $image; ?>" alt="<?php echo $name; ?>">
                <?php if ($logged_in): ?>
                    <?php if ($in_wishlist): ?>
                        <form action="remove_from_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <input type="hidden" name="remove" value="1">
                            <button type="submit" class="heart-btn active">
                                <i class="fas fa-heart"></i>
                            </button>
                        </form>
                    <?php else: ?>
                        <form action="add_to_wishlist.php" method="POST">
                            <input type="hidden" name="flower_image" value="<?php echo $image; ?>">
                            <button type="submit" class="heart-btn">
                                <i class="far fa-heart"></i>
                            </button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="heart-btn" onclick="loginPrompt()">
                        <i class="far fa-heart"></i>
                    </button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<div class="footer-spacer"></div>

<footer class="footer">
    <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
</footer>

<script>
    function toggleMenu() {
        var menu = document.querySelector('.menu');
        menu.classList.toggle('active');
    }
    
    function loginPrompt() {
        alert('Please sign in to add items to your wishlist!');
        window.location.href = 'signin.php';
    }
    
    function goToWishlist() {
        <?php if ($logged_in): ?>
            window.location.href = 'wishlist.php';
        <?php else: ?>
            loginPrompt();
        <?php endif; ?>
    }
</script>

</body>
</html>