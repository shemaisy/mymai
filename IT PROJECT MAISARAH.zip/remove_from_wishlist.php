<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Check if removing from wishlist page (with wishlist_id)
    if (isset($_POST['wishlist_id'])) {
        $wishlist_id = $_POST['wishlist_id'];
        
        $stmt = $conn->prepare("DELETE FROM wishlist WHERE wishlist_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $wishlist_id, $user_id);
        
        if ($stmt->execute()) {
            header('Location: wishlist.php?message=Item removed from wishlist');
        } else {
            header('Location: wishlist.php?error=Error removing item from wishlist');
        }
    } 
    // Check if removing from showcase page (with flower_image)
    elseif (isset($_POST['flower_image']) && isset($_POST['remove'])) {
        $flower_image = $_POST['flower_image'];
        
        $stmt = $conn->prepare("DELETE FROM wishlist WHERE flower_image = ? AND user_id = ?");
        $stmt->bind_param("si", $flower_image, $user_id);
        
        if ($stmt->execute()) {
            header('Location: showcase.php');
        } else {
            echo "<script>alert('Error removing from wishlist.'); window.location.href = 'showcase.php';</script>";
        }
    } else {
        header('Location: showcase.php');
    }
}
?>