<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $bouquet = $data['bouquet'];
    $user_id = $_SESSION['user_id'];

    // Insert custom bouquet into the database
    $stmt = $conn->prepare("INSERT INTO custom_orders (user_id, bouquet) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, json_encode($bouquet));

    if ($stmt->execute()) {
        echo "Custom order received!";
    } else {
        http_response_code(500);
        echo "Failed to submit custom order.";
    }

    $stmt->close();
    $conn->close();
} else {
    http_response_code(405); // Method Not Allowed
    echo "Invalid request method.";
}
?>