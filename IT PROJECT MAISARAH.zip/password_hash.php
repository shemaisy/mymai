<?php
$hashed_password = password_hash("sarah123", PASSWORD_DEFAULT);
echo $hashed_password;
?>
