<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];
// Updated query to fetch only from orders table
$purchases_query = $conn->query("
    SELECT 
        order_id, 
        CASE 
            WHEN is_custom = 1 THEN 'Custom'
            ELSE 'Regular'
        END as order_type,
        flower_type as item_description, 
        order_date, 
        status, 
        payment_method,
        address_line1, 
        city, 
        state, 
        postal_code,
        bouquet_details
    FROM orders 
    WHERE user_id = $user_id
    ORDER BY order_date DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Purchase History - MyMai</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: 'Lucida Bright', sans-serif;
            background-color: #ffebf0;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #ffebf0;
            border: 2px solid #f4a1c1;
            padding: 10px;
            text-align: center;
            font-family: 'Vivaldi';
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            position: relative;
        }

        .header .logo {
            height: 40px;
            width: auto;
        }

        .header h1 {
            font-size: 24px; 
            margin: 0; 
        }

        .purchase-container {
            max-width: 800px;
            margin: 20px auto 80px;
            padding: 20px;
            background-color: white;
            border: 2px solid #f4a1c1;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .purchase-container h2 {
            font-size: 28px;
            color: #f4a1c1;
            margin-bottom: 20px;
            text-align: center;
        }

        .purchase-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .purchase-table th {
            background-color: #f4a1c1;
            color: white;
            padding: 12px;
            text-align: left;
        }

        .purchase-table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }

        .purchase-table tr:hover {
            background-color: #ffebf0;
        }

        .no-purchases {
            text-align: center;
            font-size: 18px;
            color: #777;
            margin-top: 20px;
        }

        .back-button-container {
            text-align: center; 
            margin-top: 20px; 
        }

        .back-button {
            display: inline-block;
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #ffebf0;
            color: black;
        }
        
        /* Profile Dropdown Styles */
        .profile-dropdown {
            position: absolute;
            top: 10px;
            right: 20px;
            z-index: 100;
        }

        .profile-dropdown .dropdown-button {
            background-color: #f4a1c1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .profile-dropdown .dropdown-button:hover {
            background-color: #ffebf0;
            color: black;
        }

        .profile-dropdown .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .profile-dropdown .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .profile-dropdown .dropdown-content a:hover {
            background-color: #f4a1c1;
            color: white;
        }

        .footer {
            background-color: #f4a1c1;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            font-family: 'Lucida Bright';
        }

        .footer p {
            margin: 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="../PHP/flowerpicture/flower.png" alt="Logo" class="logo">
        <h1>MyMai</h1>
        
        <!-- User Profile Dropdown -->
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="profile-dropdown">
            <button class="dropdown-button">My Profile</button>
            <div class="dropdown-content">
                <a href="wishlist.php">Wishlist</a>
                <a href="edit_address.php">Edit Address</a>
                <a href="purchase_history.php">Purchase History</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="purchase-container">
        <h2>Your Purchase History</h2>
        
        <?php if ($purchases_query->num_rows > 0): ?>
            <table class="purchase-table">
    <thead>
        <tr>
            <th>Order ID</th>
            <th>Date</th>
            <th>Type</th>
            <th>Items</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($order = $purchases_query->fetch_assoc()): ?>
            <tr>
                <td>#<?= $order['order_id']; ?></td>
                <td><?= date('M d, Y', strtotime($order['order_date'])); ?></td>
                <td><?= $order['order_type']; ?></td>
                <td>
                    <?php 
                    if ($order['order_type'] == 'Regular') {
                        echo htmlspecialchars($order['item_description']);
                    } else {
                        // For custom orders, check if bouquet_details is a valid JSON
                        $flowers = json_decode($order['bouquet_details'], true);
                        if (is_array($flowers)) {
                            echo implode(', ', array_map('ucfirst', $flowers));
                        } else {
                            echo 'Custom Bouquet';
                        }
                    }
                    ?>
                </td>
                <td><?= $order['status']; ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

        <?php else: ?>
            <p class="no-purchases">You haven't made any purchases yet.</p>
        <?php endif; ?>
        
        <div class="back-button-container">
            <a href="index.php" class="back-button">Back to Home</a>
        </div>
    </div>
    
    <footer class="footer">
        <p>&copy; 2024 MyMai Crochet Wonderland. All rights reserved.</p>
    </footer>
    
    <script>
        // Profile dropdown functionality
        document.addEventListener("DOMContentLoaded", function() {
            // Close the dropdown if the user clicks outside of it
            document.addEventListener("click", function(event) {
                const dropdown = document.querySelector(".profile-dropdown");
                if (dropdown && !dropdown.contains(event.target)) {
                    const dropdownContent = dropdown.querySelector(".dropdown-content");
                    if (dropdownContent) {
                        dropdownContent.style.display = "none";
                    }
                }
            });

            // Toggle dropdown visibility
            const dropdownButton = document.querySelector(".dropdown-button");
            if (dropdownButton) {
                dropdownButton.addEventListener("click", function(event) {
                    event.stopPropagation();
                    const dropdownContent = this.nextElementSibling;
                    if (dropdownContent) {
                        dropdownContent.style.display = dropdownContent.style.display === "block" ? "none" : "block";
                    }
                });
            }
        });
    </script>
</body>
