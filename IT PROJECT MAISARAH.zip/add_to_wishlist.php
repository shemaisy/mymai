<?php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $flower_image = $_POST['flower_image']; // Get image instead of name

    // Check if the item is already in the wishlist
    $check_stmt = $conn->prepare("SELECT * FROM wishlist WHERE user_id = ? AND flower_image = ?");
    $check_stmt->bind_param("is", $user_id, $flower_image);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "<script>alert('This item is already in your wishlist!'); window.location.href = 'showcase.php';</script>";
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO wishlist (user_id, flower_image) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $flower_image);

    if ($stmt->execute()) {
        echo "<script>alert('Added to wishlist!'); window.location.href = 'showcase.php';</script>";
    } else {
        echo "<script>alert('Error adding to wishlist.'); window.location.href = 'showcase.php';</script>";
    }
}
?>